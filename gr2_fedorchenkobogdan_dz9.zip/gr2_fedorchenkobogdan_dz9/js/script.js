const about_me = {
  name:' Моё имя Федорченко Богдан',
  age:19,
  mesage:'я хочу научится делать верстку и другое...'
}
console.log(about_me);
function about() {
  let myName = 'Моё имя Федорченко Богдан';
  console.log(myName);
  let myAge='Мне 19 лет';
  console.log(myAge);
  let myAspirations='я хочу научится делать верстку и другое...';
  console.log(myAspirations)
}
about()